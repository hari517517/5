﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinApp_AsyncAwaitDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnShow_Click(object sender, EventArgs e)
        {            
            lblMessage.Text = "Processing File! Please Wait!";
            int count = GetCharCount();        
            lblMessage.Text = "Total Chars Count from File: "+count;
        }

        public int GetCharCount()
        {
            int count = 0;
            count = File.ReadAllText("multiple_upload.html").Length;
            return count;
        }
    }
}
