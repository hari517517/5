﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo1
{
    class Program
    {
        static void Main(string[] args)
        {            
            Employee manager = new Manager(101, "Amit", 10000); 
            manager.CalcSalary();
            Console.WriteLine( manager.GetDetails());

            Console.ReadKey();
        }
    }
}
