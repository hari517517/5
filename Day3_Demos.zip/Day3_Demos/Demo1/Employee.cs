﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo1
{
    //Object Based PL - Abstraction-Encapsulation - Has Relation - Reusability
    //Object Oriented PL - Abstraction-Encapsulation-Inheritance-Polymorphism(Runtime)  - + Is Relationship (inheritance) - Reusability+Extensibility()
    //VB-6.0 - Class-Yes | No-Inheritance, No-Runtime Polymorphism
    //Has Relation - Reusability

    abstract class Employee {
        protected int empId;
        protected string empName;
        protected double salary, gs, ns, pf;
       
        public Employee(int empId, string empName, int salary)
        {
            this.empId = empId;
            this.empName = empName;
            this.salary = salary;
        }      

        //public abstract double NS { set; }
        public virtual double NS { set { ns = value; } }

        public abstract void CalcSalary();
        //{
        //    pf = salary * 0.12;
        //    gs = salary + pf;
        //    ns = gs - pf;
        //}

        public string GetDetails()
        {
            return "EmpId: " + empId + ", Name: " + empName + ", GS: " + gs + ", NS: " + ns;
        }
    }
    class Manager : Employee {
        double incentives;
        public Manager(int empId, string empName, int salary)
            : base(empId, empName, salary)
        {
            incentives = 5000;
        }

        public override void CalcSalary()
        {
            pf = salary * 0.12;
            gs = gs + incentives;
            ns = gs - pf;
        }

        public override double NS { set { ns = value; } }
    }      
}
