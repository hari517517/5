﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo2
{
    class Program
    {
        static void Main(string[] args)
        {
            MyClass myClass = new MyClass();
           
            IOne o = myClass;
            o.M1();
            ITwo t = myClass;
            t.M1();

            Console.ReadKey();
        }
    }
}
