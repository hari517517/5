﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo2
{
    class MyClass : IMyInterface
    {
        void IOne.M1() //IOne
        {
            Console.WriteLine("IOne.M1()");
        }
        void ITwo.M1()
        {
            Console.WriteLine("ITwo.M1()");
        }
        public void M2() 
        {
            Console.WriteLine("M2()");
        }      
    }
}
