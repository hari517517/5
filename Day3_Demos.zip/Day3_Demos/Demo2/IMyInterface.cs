﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo2
{
    interface IMyInterface : IOne, ITwo
    {
        void M2();
    }
}
