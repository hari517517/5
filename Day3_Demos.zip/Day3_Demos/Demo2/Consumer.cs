﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo2
{
    class Consumer
    {
        ICalcService ServiceProvider = new ServiceProvider();       
        public int Add(int n1, int n2)
        {
            return ServiceProvider.Add(n1, n2);
        }
    }
}
