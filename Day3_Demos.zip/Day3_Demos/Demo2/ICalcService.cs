﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo2
{
    interface ICalcService
    {
        int Add(int n1, int n2);
        int Sub(int n1, int n2);
    }
}
