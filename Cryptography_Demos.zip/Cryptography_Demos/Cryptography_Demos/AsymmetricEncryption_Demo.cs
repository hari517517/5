﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;

namespace Cryptography_Demos
{
    class AsymmetricEncryption_Demo
    {
        static byte[] Encrypt(string publicKey, byte[] data)
        {
            byte[] cipherData = null;
            using (RSACryptoServiceProvider rsa = new RSACryptoServiceProvider())
            {
                // Set the rsa pulic key   
                rsa.FromXmlString(publicKey);
                // Encrypt the data and store it in the encyptedData Array   
                cipherData = rsa.Encrypt(data, false);
            }
            return cipherData;
        }
        static byte[] Decrypt(string privateKey, byte[] cipherData)
        {
            byte[] plainData;
            using (RSACryptoServiceProvider rsa = new RSACryptoServiceProvider())
            {
                //Setting the private key of the algorithm
                rsa.FromXmlString(privateKey);
                plainData = rsa.Decrypt(cipherData, false);
            }
            return plainData;
        }
        static void Main(string[] args)
        {            
            //Accepting data to be used for Cryptography.
            Console.WriteLine("Enter any Message here: ");
            string originalMessage = Console.ReadLine();

            //Creating Asymmetric Algorithm instance
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();

            //Getting the public & private keys
            string publicKey = rsa.ToXmlString(false); // false to get the public key   
            string privateKey = rsa.ToXmlString(true); // true to get the private key   

            //Getting bytes from string
            byte[] b_originalMessage = Encoding.UTF8.GetBytes(originalMessage);

            //passing bytes to method for encryption purpose
            byte[] cipherMessage = Encrypt( publicKey, b_originalMessage);            

            //passing encrypted bytes to method for decryption purpose
            byte[] b_message = Decrypt( privateKey, cipherMessage);

            //Getting string from bytes
            string message = Encoding.UTF8.GetString(b_message);

            if (originalMessage.Equals(message))
            {
                Console.WriteLine($"Both Original-Message & Message-Decrypted are same...\n{originalMessage}\n{message}");
            }
            else
            {
                Console.WriteLine($"Both Original-Message & Message-Decrypted are NOT same...\n{originalMessage}\n{message}");
            }

            Console.ReadKey();
        }
    }

}
