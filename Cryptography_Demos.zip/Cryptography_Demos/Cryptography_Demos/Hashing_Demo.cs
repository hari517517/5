﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Cryptography_Demos
{    
    class Hashing_Demo
    {
        static void Main(string[] args)
        {
            Console.Write("Enter Your Message here: ");
            string hash1 = ComputeSha256Hash(Console.ReadLine());
            Console.WriteLine(hash1);
            Console.Write("Verify the Message again: ");
            string hash2 = ComputeSha256Hash(Console.ReadLine());
            Console.WriteLine(hash2);
            if (hash1 == hash2)            
                Console.WriteLine("Matching!");
            else
                Console.WriteLine("Not Matching!");

            Console.ReadKey();
        }      
        static string ComputeSha256Hash(string rawData)
        {
            // Create a SHA256   
            using (SHA256 sha256Hash = SHA256.Create())
            {
                //ComputeHash - returns byte array  
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));
                //Converting byte array into string & returning it.
                return String.Join("-", bytes);                                
            }
        }
    }
}
