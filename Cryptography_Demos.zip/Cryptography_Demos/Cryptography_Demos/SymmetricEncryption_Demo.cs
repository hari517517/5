﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;

namespace Cryptography_Demos
{
    class SymmetricEncryption_Demo
    {
        static byte[] Encrypt(SymmetricAlgorithm alg, byte[] data)
        {
            ICryptoTransform encryptor = alg.CreateEncryptor(alg.Key, alg.IV);
            var cipherData = encryptor.TransformFinalBlock(data, 0, data.Length);
            return cipherData;
        }
        static byte[] Decrypt(SymmetricAlgorithm alg, byte[] cipherData)
        {
            ICryptoTransform decryptor = alg.CreateDecryptor(alg.Key, alg.IV);
            var plainData = decryptor.TransformFinalBlock(cipherData, 0, cipherData.Length);
            return plainData;
        }
        static void Main(string[] args)
        {           
            //Accepting data to be used for Cryptography.
            Console.WriteLine("Enter any Message here: ");
            string originalMessage = Console.ReadLine();

            //Creating Symmetric Algorithm instance by using any Symmetric Algorithm Class
            SymmetricAlgorithm aes = new AesManaged();

            //Getting bytes from string
            byte[] b_originalMessage = Encoding.UTF8.GetBytes(originalMessage);           
            
            //passing bytes to method for encryption purpose
            byte[] cipherMessage = Encrypt(aes, b_originalMessage);
            
            //passing encrypted bytes to method for decryption purpose
            byte[] b_message = Decrypt(aes, cipherMessage);

            //Getting string from bytes
            string message = Encoding.UTF8.GetString(b_message);

            if (originalMessage.Equals(message))
            {
                Console.WriteLine($"Both Original-Message & Message-Decrypted are same...\n{originalMessage}\n{message}");
            }
            else
            {
                Console.WriteLine($"Both Original-Message & Message-Decrypted are NOT same...\n{originalMessage}\n{message}");
            }

            Console.ReadKey();
        }
    }    
}
