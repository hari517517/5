﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Cryptography_Demos
{  
    class HashingApplication
    {
        static void Main(string[] args)
        {
            Console.Write("Set Your Password: ");
            StorePasswordHash(Console.ReadLine());

            Console.Write("Verify Your Password: ");
            string enteredPwd = Encoding.UTF8.GetString(ComputeSha256Hash(Console.ReadLine()));
            string storedPwd = Encoding.UTF8.GetString(GetPasswordHash());

            if (enteredPwd == storedPwd)
                Console.WriteLine("You have entered CORRECT Password!");
            else
                Console.WriteLine("You have entered INCORRECT Password!");

            Console.ReadLine();
        }

        private static void StorePasswordHash(string password)
        {            
            File.WriteAllBytes("password.txt", ComputeSha256Hash(password));
            Console.Write("Your Password set successfully!");
        }
        private static byte[] GetPasswordHash()
        {
            return File.ReadAllBytes("password.txt");
        }
        static byte[] ComputeSha256Hash(string rawData)
        {
            // Create a SHA256   
            using (SHA256 sha256Hash = SHA256.Create())
            {
                // ComputeHash - returns byte array  
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));
                return bytes;
            }
        }
    }
}
