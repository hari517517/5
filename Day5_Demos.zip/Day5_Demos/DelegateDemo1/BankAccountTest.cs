﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateDemo1
{
    class BankAccountTest
    {
        static void Main(string[] args)
        {
            NotificationDelegate notifiDel = new NotificationDelegate(Notifications.SendSMS);
            notifiDel += new NotificationDelegate(Notifications.SendMail);
            BankAccount bankAccount = new BankAccount(102, 10000, notifiDel);
         
            bankAccount.With(1000);
            //bankAccount.Depo(200);


            Console.ReadKey();
        }
    }
}
