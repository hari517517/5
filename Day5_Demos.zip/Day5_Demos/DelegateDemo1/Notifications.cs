﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateDemo1
{
    delegate void NotificationDelegate(string message);
    class Notifications
    {
        public static void SendSMS(string message)
        {
            //Consider that this code is to send SMS.
            Console.WriteLine("SMS: "+message);
        }
        public static void SendMail(string message)
        {
            //Consider that this code is to send Mail.
            Console.WriteLine("Mail: " + message);
        }
        public static void SendVoiceCall(string message)
        {
            //Consider that this code is to send Voice Call.
            Console.WriteLine("Voice-Call: " + message);
        }
    }
}
