﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateDemo1
{
    class BankAccount
    {
        public int AccNo { get; set; }
        public double Balance { get; set; }

        NotificationDelegate notification;

        public BankAccount(int accNo, double balance, NotificationDelegate notification)
        {
            this.AccNo = accNo;
            this.Balance = balance;
            this.notification = notification;
        }
        public void With(double amount)
        {
            if(Balance >= amount)
            {
                double oldBal = Balance;
                Balance -= amount;
                notification($"With: Balanced Updated from {oldBal} to {Balance}");
            }
        }
       
        public void Depo(double amount)
        {
            double oldBal = Balance;
            Balance += amount;
            notification($"Depo: Balanced Updated from {oldBal} to {Balance}");
        }
    }
}
