﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SOLID_Principles_Demo.SRP;

namespace SOLID_Principles_Demo.OCP //Open closed principle 
{
    //class should be open for extension but closed for modification
    public class ReportGeneration
    {      
        public string ReportType { get; set; }     
        public void GenerateReport(Employee em)
        {
            if (ReportType == "CRS")
            {
                // Crystal Report Report generation
            }
            if (ReportType == "PDF")
            {
                //PDF Report generation
            }
        }
    }
}
