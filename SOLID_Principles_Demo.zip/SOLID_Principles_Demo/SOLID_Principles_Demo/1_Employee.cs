﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLID_Principles_Demo.SRP //Single responsibility principle
{
    //A class should take one responsibility and there should be one reason to change that class
    public class Employee
    {
        public int Employee_Id { get; set; }
        public string Employee_Name { get; set; }
       
        public bool InsertIntoEmployeeTable()
        {
            //Code here to insert into Employee table.
            return true;
        }  
        //public void GenerateReport()
        //{
        //    // Report generation with employee data using crystal report.
        //}
    }



















    public class ReportGeneration
    {     
        public void GenerateReport(Employee em)
        {
            // Report reneration with employee data.
        }
    }
}
