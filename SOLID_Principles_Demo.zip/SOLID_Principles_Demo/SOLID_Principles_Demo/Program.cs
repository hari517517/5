﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLID_Principles_Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Single Responsibility Principle - 1_Employee
            //Open closed principle - 2_1_ReportGeneration & 2_2_IReportGeneration
            //Liskov substitution principle - 3_LSP_Employee
            //Interface segregation principle - 4_IDatabase
            //Dependency inversion principle - 5_

            //
        }
    }
}
